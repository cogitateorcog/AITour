SAP AGENT OPPORTUNITY WORKSHOP — OFFLINE KIT

START HERE
1. Extract the entire ZIP into a folder permitted by your organisation.
2. Open START-HERE.html in an approved browser. Follow its compatibility check.
3. Open business-ai-sap-workshop.html. Choose Find an opportunity to start
   from a process observation, or Bring an existing use case to shape your idea.
   Both routes join the same builder, tests and readout.

Open the extracted files, not a file still inside the ZIP or an email/Teams
preview. Keep the kit together. No installation, Node, npm, Python, admin
rights, SAP account or network connection is required by the exercise.
Your organisation's browser and file policies still apply.
Learn with the worked example first previews a fictional Signavio insight.
Challenge the process-fix / fixed-rule alternative, then choose Develop this
opportunity to load the completed reference. Closing the preview keeps current
work. Use Resume saved example to reopen an explicitly saved example directly.
Start own case in the header begins a clean group idea after confirmation.

WORKSHOP AIM
Choose an SAP value stream and describe 3-5 current activities with existing
roles and systems. Identify a recurring business problem, then a first agent
job. Ground the prototype in one fictional or anonymised situation. Build and
test a normal case and an exception before discussing the common core, where
it could be reused and what needs adapting across industries and SAP landscapes.
No client case counts or API knowledge are needed to start. A specific SAP
system is an illustrative deployment, not a requirement for the pattern.

THE 45-MINUTE CORE
1. Find pain (8 min): a short current process, one problem, one first agent
   job and one situation to prototype.
2. Shape use case (8 min): Copy first idea into the job carries your idea forward.
   Refine result and its user, trigger, information, human responsibility and
   stop rule. Use business roles; applications are deployment choices to confirm.
   Use Define information context — SAP BDC to name one or two facts, their
   meaning / relationships, sources, owners, freshness and proposed supply.
   Name every required fact and keep at least one required item for the normal
   and missing-evidence tests. Unknown sources and owners remain follow-up
   questions. Save context and return keeps these in current work; no blocks or test
   values are needed. Unknowns can stay to confirm. Leave pilot detail until Share.
3. Map the flow (7 min): Suggest a first map creates an editable five-step
   starting pattern with your notes. Review Today's process - reference first,
   then map the proposed future flow. Do not duplicate the entire current process. Begin with the event that starts one case and identify the
   work the agent takes on. Change or remove activities to fit the situation.
   Activity names wrap as you type; Optional step details can stay closed.
4. Build & try (18 min): Draft from our process map, then Edit sample result.
   In Add an exception handoff, choose the information step under Which step
   might get stuck?, name the owner under Who takes over?, then Add handoff.
   Under Use our information context, choose the information block and Apply
   context to this block. Beside the runner, choose Prepare test case to supply
   fictional values and conditions for the normal and exception cases.
   Inspect both traces and context snapshots; record both verdicts.
5. Share prototype (4 min): agree one next question and rehearse the four
   prompts already filled from your work. Readouts take one minute per team:
   problem (10 sec), proposed agent and human boundary (15 sec), normal and
   exception observations (15 sec), expected value and next question (20 sec).
   For the team holds the full record, reuse reflections, questions, scoring
   and pilot planning. These are optional follow-up, not presentation tasks.
Rotate the operator between stages; others challenge behaviour, information
and value. Suggested maps leave the canvas unchanged until you draft from the
map. Replacing an existing job or map requires confirmation. No SAP write
permission is inferred. The handoff helper keeps the usual route and asks you
to resolve conflicting branches; manual connections remain optional.
Each stage shows one next action based on the group's entries and observations.
These prompts guide the conversation; they do not validate answers or lock
navigation. Discuss the visible Does this need an agent? question before
proposing a job; a process change or fixed rule can be a valid conclusion.

If the job, information, human review or stop rule changes, review the canvas
and rerun both cases. Process-map edits do not update canvas blocks; check the
map/canvas warning before presenting. If you manually reconcile the canvas,
choose Keep this canvas after review; this preserves blocks and exception
branches. Review changed Shape answers against the map separately. Rerun both
cases after a design change. Test-condition-only changes preserve
the design and earlier observations.
Changes to Shape answers also flag an earlier suggested map for review.
Suggest a replacement or choose Keep this map after review; this does not
rewrite the map or canvas. Performer says who does the work. Type of activity
selects the prototype behaviour. A human activity does not pause for approval;
choose Ask for approval only if the flow must wait for acceptance or rejection.
Map test notes appear by the runner; notes do not create exception connections.
Map guidance points to an unnamed or unfinished activity before asking the
group to identify an agent contribution. These reminders do not block drafting
or infer activity types from the words entered. Maps support up to 100 steps;
a short usual path is enough for this exercise.
The core Check proposed responsibilities and handoffs preview stays visible;
review who does each activity and every handoff before building.
Use Earlier / Later in the handoff preview; performer names stay visible.
In the builder, Fit flow, zoom and 100% adjust the view without changing work.
Long flows scroll at a readable size. Add blocks opens the block library.
Choose a block or path above the canvas to edit it without dragging; move a
block by its heading. Dashed paths are exceptions; select one to read its label.
Optional use-case notes show the answers already captured, with one prompt
back to any missing essentials. The handoff preview shows used performer lanes
and dashed placeholders for unfinished rows. It does not connect across those
rows or add exception branches; finish the table before reviewing the flow.

VALUE-STREAM SAMPLE LIBRARY
In the header, choose Value-stream samples. Preview without changing work,
then explicitly choose Load this sample. Loading replaces the current design
and clears the test session after confirmation. Each sample is fictional and
editable, with a short current process, proposed map, agent flow, Signavio
observation, LeanIX source owners, BDC context and fictional test values.
No recorded observations or verdicts are preloaded. All eight named streams:
- Source-to-Pay: explain a blocked price variance.
- Order-to-Cash: review an at-risk delivery.
- Record-to-Report: explain a reconciliation difference.
- Hire-to-Retire: check onboarding readiness.
- Plan-to-Fulfil: review supply-shortage options.
- Design-to-Operate: review asset-maintenance evidence.
- Lead-to-Cash: check proposal requirements before commitment.
- Service-to-Customer: review a service case's next step.
Start in Find pain and compare today's process with the proposed job. In
Build & try, Prepare test case with all required evidence available, Run case,
Approve if requested, then Continue run. Inspect and record your verdict.
For the exception, Prepare test case again, make one required source unavailable
in Test conditions, prepare and run again. Expect the named human handoff
before a recommendation. Inspect the trace and record the second verdict.
Start own case clears sample content. Saved samples stay opt-in on a fresh
reopen: Resume saved sample restores the design with fresh tests. Legacy work
without today's process opens with an empty reference; no baseline is inferred
from its AI-assisted proposal. Full records and editable work preserve the
current-process note; the one-minute readout remains four short prompts.

OPTIONAL FOLLOW-UP: PLAN A CONNECTED PILOT
After the tests, Share prototype → For the team has Plan a connected pilot.
Use it for additional information detail, proposed boundaries and protections,
implementation questions, source names, access and a benefit measure. Existing
saved answers remain editable there. Leave baselines as to measure if unknown.
These are design proposals: selecting a protection or autonomy option does not
add or enforce a builder control. Add the relevant blocks and connections to
test the behaviour. Review and rerun both cases if a design boundary changes.
This follow-up is outside the 45-minute core.

OPTIONAL EXTRA: QUICK SCORE
The full eight-question Quick score is under Share prototype → For the team. Allow an additional
5-7 minutes if time permits, outside the 45-minute core. A numeric score is not
required for the readout. Value considers reuse potential, friction removed
and business outcomes; complexity considers information, coordination,
interpretation, variation and consequences. When importing older task-based
ratings, retain them as the previous assessment and rerate the value-stream
questions only if using the optional assessment.

CONTENTS
START-HERE.html                 Setup and compatibility check
business-ai-sap-workshop.html  Interactive workshop and prototype simulation
FACILITATOR-GUIDE.html         Timings, facilitation, saving and recovery
BACKUP-WORKSHEET.html          Printable / on-screen paper fallback
README.txt                    This file

COPY FRESHNESS
After changes to work or recorded observations, the copy panel flags the
prepared text as an earlier snapshot. Show the export again. Select all text,
Copy displayed text or refocusing a supported copy export refreshes it. If an
older download fallback cannot be refreshed, choose a current export first.

WHAT THE PROTOTYPE DOES
No LLM generates answers. Your group supplies sample outputs for the simulation.
The exercise runs a deterministic browser simulation with fictional evidence.
Test conditions and drawn connections determine the path; free text is not
interpreted by AI. Signavio, LeanIX and BDC are teaching lenses here.
No live SAP records, external AI models or connected agents are accessed.
Use fictional or sanitised content permitted for the workshop.
If a normal flow has no intended sample response, the result says Flow checked;
sample result still missing. Use Edit sample result and rerun. Input facts do
not substitute for a recommendation sample. The full workshop record retains samples shown.
Expected path observed in the example refers to its configured flow, not to
an LLM's reasoning or the quality of a connected solution.

THE THREE PERSPECTIVES
1. Find pain: Investigate a process pain opens a three-step worksheet: locate
   a current activity, describe the problem, then Choose this pain area and
   return. Use group experience; no live Signavio analysis runs. Basis,
   discussion starters and effort estimates are optional. Once a problem is
   chosen, Add observation and return keeps that problem and the agent idea.
   Existing-use-case groups can skip this step. Draft observations stay labelled
   in supporting notes; only added observations appear in the opportunity summary. The full workshop record also retains supporting drafts, explicitly labelled as not yet added.
2. Shape use case: LeanIX connects a business capability (what the business
   must be able to do) to supporting applications, their contribution and
   owners. One or two applications, repositories or services are enough.
   Reuse and change check is optional: what stays the same and what needs
   checking in another landscape? Use these dependencies in our design saves
   architecture notes; it does not connect applications or configure the agent.
   Draft landscape choices stay labelled until added. Next, Define information
   context — SAP BDC captures what those facts mean and how they could be supplied.
   Save context and return does not attach a block or prepare a test.
3. Map the flow: describe the proposed agent flow, separate from today's process.
4. Build & try: Use our information context shows the definition already made
   in Shape. Apply context to this block adds it to the chosen information step,
   preserving other notes. It does not connect, prepare or run anything. Use
   Review or edit the definition only if needed. Prepare test case beside the
   runner opens a separate Test conditions view. Supply
   fictional sample values and keep required evidence current and available.
   Prepare test case, then Run case. For the exception, change one condition
   and prepare again without updating the block. Both runs retain their own
   values, availability and quality. Meaning, freshness and delivery unknowns
   stay validation questions; the simulation does not interpret them with AI.
   If the definition or graph changes, review / save and rerun both cases.
   Review process, sources and evidence brings the perspectives together.
5. Share prototype: the one-minute readout shows the problem, agent, two
   observations and expected value plus one next question. For the team holds
   the full record: context definition, frozen run snapshots, evidence and
   open questions. Reuse and adaptation discussion can continue there later.

SAVE AT CHECKPOINTS
Download one-minute readout saves a short offline presentation. It is not
the full evidence record. Shortened text is marked with “…”; complete answers
stay in the full record.
In Share prototype → Save or continue later, save BOTH:
- Save editable work file (.json): resume the design using Open work file.
- Full record HTML or Full record text (.md): retain the observed runs and verdicts.

Test observations belong to the current session. Restoring editable JSON or
opening a runnable prototype starts a fresh test session. Keep the full record.

IF DOWNLOADS OR BROWSER STORAGE ARE BLOCKED
Use header Copy / restore, or Share prototype → Save or continue later
→ Copy or restore without downloads.
Use Show editable work and Show full record text to keep the complete work.
Show one-minute readout is the short presentation; Show runnable prototype
keeps a runnable design with fresh tests.
Select and copy the displayed text manually if automatic clipboard fails.
Paste into an approved plain-text editor, save as UTF-8, and use the matching
.json, .md or .html extension (not .txt). Keep the complete text unchanged.
Verify both external copies are complete before testing restore. Open a fresh
workshop tab and paste the JSON into Restore pasted work. Keep the original
tab open until the restored design is checked. JSON does not restore earlier
test observations; those remain in the full record.
If clipboard and downloads are unavailable, use BACKUP-WORKSHEET.html.

IF LOCAL HTML IS BLOCKED
Use a facilitator's approved device, or ask IT for an approved internal
static-web hosting route. Do not disable security controls or use portable
executables to evade policy. The kit cannot override company restrictions.

FACILITATOR PREFLIGHT
Before the workshop, use the exact distribution channel and a representative
managed laptop to check extraction, browser interaction, normal and exception
runs, saving, copy fallback, reopening work and offline operation.

Print FACILITATOR-GUIDE.html and BACKUP-WORKSHEET.html from the browser if useful.

TIME AND SCOPE
The exercise is 45 minutes: Find pain 8, Shape 8, Map 7, Build & try 18,
Share preparation 4. One-minute team readouts follow. Press Start timer at the
top right; it stays visible across stages and flashes slowly at one minute.
Pause / Resume is available. Reloading starts a fresh timer in that tab.
Keep one situation, 1-2 sources, 1-2 required facts and one missing-source
exception. Use a sample if needed; make one deliberate change before testing.
Leave deeper discovery, scoring and architecture for follow-up.

BDC SEMANTIC CONTEXT
Define shared business meaning, matching references, units and freshness.
Separate the original SAP or non-SAP source from the agent access route.
A proposed BDC data product or semantic model needs supported integration
and authorised consumption; direct sources and separate guidance remain valid.
This worksheet creates no live semantic model or Knowledge Graph connection.
Read access does not grant business-record write permission. The full record
keeps proposed-delivery validation questions. Optional product references are
in the BDC background and facilitator guide (researched 29 October 2026).
